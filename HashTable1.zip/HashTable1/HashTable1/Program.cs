﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace HashTable1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*
            Hashtable ht = new Hashtable();
            ht.Add(1, "Apple");
            ht.Add(2, "Mango");
            ht.Add(3, "Strawberry");
            ht.Add(4, "Banana");

            //foreach(string key in ht.Keys)
            //foreach(string value in ht.Values)
            foreach(DictionaryEntry entry in ht)
            {
                Console.WriteLine($"Key: {entry.Key}, Value: {entry.Value}");
            }
            */

            Hashtable stuTable = new Hashtable();
            stuInfo stu1 = new stuInfo()
            {
                Name = "A",
                Gender = "Female",
                Standard = "12"
            };
            stuInfo stu2 = new stuInfo()
            {
                Name = "B",
                Gender = "Male",
                Standard = "6"
            };
            stuInfo stu3 = new stuInfo()
            {
                Name = "C",
                Gender = "Female",
                Standard = "12"
            };
            stuInfo stu4 = new stuInfo()
            {
                Name = "D",
                Gender = "Female",
                Standard = "10"
            };

            stuTable.Add(101,stu1);
            stuTable.Add(102, stu2);
            stuTable.Add(103, stu3);
            stuTable.Add(104, stu4);

            Console.WriteLine("\nStudent Information");
            foreach(DictionaryEntry e in stuTable)
            {
                stuInfo info = stuTable[e.Key] as stuInfo;
                Console.WriteLine("Rollno : " + e.Key);
                Console.WriteLine("Name : " + info.Name);
                Console.WriteLine("Gender : "+info.Gender);
                Console.WriteLine("Standard : "+info.Standard);
            }
        }
    }
    public class stuInfo
    {
        public string Name { get; set; }
        public string Gender { get; set; }
        public string Standard { get; set; }
    }
}
